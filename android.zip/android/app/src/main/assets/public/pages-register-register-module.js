(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-register-register-module"],{

/***/ "+mX6":
/*!***********************************************************!*\
  !*** ./src/app/pages/register/register-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: RegisterPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageRoutingModule", function() { return RegisterPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./register.page */ "gnlj");




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_3__["RegisterPage"]
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ "/al4":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/register/register.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n          <ion-back-button></ion-back-button>\r\n      </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n    <ion-row class=\"logo\">\r\n      <ion-col size=\"12\" class=\"ion-align-self-center\">\r\n          <input type=\"button\" (click)=\"uploadPicture()\">\r\n          <ion-icon name=\"add-circle-outline\"></ion-icon>\r\n      </ion-col>\r\n    </ion-row>\r\n      <ion-row class=\"form\">\r\n          <ion-col size=\"12\">\r\n              <ion-item >\r\n                  <ion-label position=\"floating\" [ngClass]=\"user.nom.trim().length < 2 ? 'errorEmail' : 'goodEmail'\">Nom</ion-label>\r\n                  <ion-input type=\"text\" [(ngModel)]=\"user.nom\"></ion-input>\r\n              </ion-item>\r\n              <ion-item>\r\n                  <ion-label position=\"floating\" [ngClass]=\"user.prenom.trim().length < 2 ? 'errorEmail' : 'goodEmail'\">Prénom</ion-label>\r\n                  <ion-input type=\"text\" [(ngModel)]=\"user.prenom\"></ion-input>\r\n              </ion-item>\r\n              <ion-item>\r\n                <ion-label position=\"floating\" [ngClass]=\"\">Date de naissance</ion-label>\r\n                <ion-input type=\"text\" [(ngModel)]=\"user.dateNaiss\"></ion-input>\r\n            </ion-item>\r\n              <ion-item>\r\n                  <ion-label position=\"floating\" [ngClass]=\"user.email.trim().length < 2 ? 'errorEmail' : 'goodEmail'\">Email</ion-label>\r\n                  <ion-input (keydown)=\"checkEmail()\" type=\"email\" [(ngModel)]=\"user.email\"></ion-input>\r\n              </ion-item>\r\n              <ion-item>\r\n                  <ion-label position=\"floating\" [ngClass]=\"user.telephone.length < 2 ? 'errorEmail' : 'goodEmail'\">Numéro de téléphone</ion-label>\r\n                  <ion-input (keyup)=\"checkPhone()\" type=\"tel\" [(ngModel)]=\"user.telephone\"></ion-input>\r\n              </ion-item>\r\n              <ion-item>\r\n                  <ion-label position=\"floating\" [ngClass]=\"user.password.trim().length < 2 ? 'errorEmail' : 'goodEmail'\">Mot de passe</ion-label>\r\n                  <ion-input type=\"password\" [(ngModel)]=\"user.password\"></ion-input>\r\n              </ion-item>\r\n              <ion-item>\r\n                  <ion-label position=\"floating\" [ngClass]=\"user.confirm_password.trim().length < 2 ? 'errorEmail' : 'goodEmail'\">Vérifier mot de passe</ion-label>\r\n                  <ion-input type=\"password\" [(ngModel)]=\"user.confirm_password\"></ion-input>\r\n              </ion-item>\r\n              <ion-item>\r\n                <ion-label position=\"floating\" [ngClass]=\"user.adresse.trim().length < 5 ? 'errorEmail' : 'goodEmail'\">Adresse</ion-label>\r\n                <ion-input type=\"text\" [(ngModel)]=\"user.adresse\"></ion-input>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label position=\"floating\" [ngClass]=\"user.code_postale < 2 ? 'errorEmail' : 'goodEmail'\">Code postale</ion-label>\r\n              <ion-input type=\"number\" [(ngModel)]=\"user.zipcode\"></ion-input>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-label position=\"floating\" [ngClass]=\"user.ville.length < 2 ? 'errorEmail' : 'goodEmail'\">Ville</ion-label>\r\n              <ion-input type=\"text\" [(ngModel)]=\"user.ville\"></ion-input>\r\n            </ion-item>\r\n          </ion-col>\r\n            <ion-col size=\"12\">\r\n                <ion-button [disabled]=\"isErrorMail || isErrorPhone || (user.password.trim() != user.confirm_password.trim() && user.confirm_password.trim().length < 2 )\" (click)=\"register()\" expand=\"full\" class=\"btnLogin\">S'inscrire</ion-button>\r\n            </ion-col>\r\n      </ion-row>\r\n      <p> <a routerLink=\"/login\">Vous êtes déjà inscrit ? Connectez vous</a> </p>\r\n  </ion-content>");

/***/ }),

/***/ "fQjJ":
/*!***************************************************!*\
  !*** ./src/app/pages/register/register.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".logo ion-col {\n  text-align: center;\n}\n.logo ion-col input {\n  padding: 15% 18%;\n  border-radius: 50%;\n}\n.logo ion-col ion-icon {\n  color: white;\n  margin-top: 30%;\n  margin-left: -27%;\n  position: absolute;\n  border-radius: 50%;\n  font-size: xxx-large;\n  background: linear-gradient(to right top, #b0a2c1, #c0b7cf, #d1ccdd, #e4e2ea, #f7f7f7);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxyZWdpc3Rlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUk7RUFFQSxrQkFBQTtBQUZKO0FBSUk7RUFFQSxnQkFBQTtFQUVBLGtCQUFBO0FBSko7QUFRSTtFQUVBLFlBQUE7RUFFQSxlQUFBO0VBRUEsaUJBQUE7RUFFQSxrQkFBQTtFQUVBLGtCQUFBO0VBRUEsb0JBQUE7RUFFQSxzRkFBQTtBQWJKIiwiZmlsZSI6InJlZ2lzdGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sb2dvIHtcclxuXHJcbiAgICBpb24tY29sIHtcclxuICAgIFxyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgXHJcbiAgICBpbnB1dCB7XHJcbiAgICBcclxuICAgIHBhZGRpbmc6IDE1JSAxOCU7XHJcbiAgICBcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIFxyXG4gICAgfVxyXG4gICAgXHJcbiAgICBpb24taWNvbiB7XHJcbiAgICBcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIFxyXG4gICAgbWFyZ2luLXRvcDogMzAlO1xyXG4gICAgXHJcbiAgICBtYXJnaW4tbGVmdDogLTI3JTtcclxuICAgIFxyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgXHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBcclxuICAgIGZvbnQtc2l6ZTogeHh4LWxhcmdlO1xyXG4gICAgXHJcbiAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQgdG9wLCAjYjBhMmMxLCAjYzBiN2NmLCAjZDFjY2RkLCAjZTRlMmVhLCAjZjdmN2Y3KTtcclxuICAgIH1cclxuICAgIFxyXG4gICAgfVxyXG4gICAgXHJcbiAgICB9Il19 */");

/***/ }),

/***/ "fhSy":
/*!***************************************************!*\
  !*** ./src/app/pages/register/register.module.ts ***!
  \***************************************************/
/*! exports provided: RegisterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageModule", function() { return RegisterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./register-routing.module */ "+mX6");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./register.page */ "gnlj");







let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _register_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegisterPageRoutingModule"]
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]]
    })
], RegisterPageModule);



/***/ }),

/***/ "gnlj":
/*!*************************************************!*\
  !*** ./src/app/pages/register/register.page.ts ***!
  \*************************************************/
/*! exports provided: RegisterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPage", function() { return RegisterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_register_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./register.page.html */ "/al4");
/* harmony import */ var _login_login_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../login/login.page.scss */ "H+1c");
/* harmony import */ var _register_page_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./register.page.scss */ "fQjJ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "a/9d");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/auth.service */ "lGQG");










let RegisterPage = class RegisterPage {
    constructor(router, camera, auth, toast, loading) {
        this.router = router;
        this.camera = camera;
        this.auth = auth;
        this.toast = toast;
        this.loading = loading;
        this.isErrorMail = true;
        this.isErrorPhone = true;
        this.user = { avatar: '', prenom: '', nom: '', email: '', dateNaiss: '', telephone: '', password: '', confirm_password: '', adresse: '', zipcode: '', ville: '', pays: '1' };
    }
    ngOnInit() { }
    checkEmail() {
        const regex = new RegExp(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/g);
        this.isErrorMail = (regex.test(this.user.email.trim())) ? false : true;
    }
    checkPhone() {
        const regex = new RegExp(/^((\+)33|0|0033)[1-9](\d{2}){4}$/g);
        this.isErrorPhone = (regex.test(this.user.telephone.trim())) ? false : true;
    }
    register() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const load = yield this.loading.create({
                message: 'Please wait...',
            });
            yield load.present();
            this.user.nom_utilisateur = this.user.email.split('@')[0];
            this.auth.register(this.user).then((data) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                console.log(data);
                yield this.loading.dismiss();
                this.router.navigate(['/login']);
            })).catch((err) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                console.log(err);
                const toast = yield this.toast.create({
                    message: err,
                    duration: 2000
                });
                toast.present();
                yield this.loading.dismiss();
            }));
        });
    }
    uploadPicture() {
        const options = {
            quality: 100,
            destinationType: this.camera.DestinationType.FILE_URI,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        };
        this.camera.getPicture(options).then((imageData) => {
            // imageData is either a base64 encoded string or a file URI
            // If it's base64 (DATA_URL):
            let base64Image = 'data:image/jpeg;base64,' + imageData;
            alert(imageData);
        }, (err) => {
            // Handle error
            alert(err);
        });
    }
};
RegisterPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_7__["Camera"] },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_8__["AuthService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] }
];
RegisterPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-register',
        template: _raw_loader_register_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_login_login_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"], _register_page_scss__WEBPACK_IMPORTED_MODULE_3__["default"]]
    })
], RegisterPage);



/***/ })

}]);
//# sourceMappingURL=pages-register-register-module.js.map