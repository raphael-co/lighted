(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["search-search-module"],{

/***/ "Dwri":
/*!*********************************************!*\
  !*** ./src/app/pages/search/search.page.ts ***!
  \*********************************************/
/*! exports provided: SearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchPage", function() { return SearchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_search_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./search.page.html */ "eQ5q");
/* harmony import */ var _login_login_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../login/login.page.scss */ "H+1c");
/* harmony import */ var _search_page_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search.page.scss */ "bHDT");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _assets_detailProduct_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../assets/detailProduct.json */ "UDca");
var _assets_detailProduct_json__WEBPACK_IMPORTED_MODULE_6___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../../../assets/detailProduct.json */ "UDca", 1);







let SearchPage = class SearchPage {
    constructor(router) {
        this.router = router;
        this.prods = _assets_detailProduct_json__WEBPACK_IMPORTED_MODULE_6__.product;
        this.ishidden = false;
        this.searchbar = "";
        this.editedText = "";
        this.arrayProduct = [];
    }
    ngOnInit() {
    }
    show_search(key) {
        let backspace = false;
        this.ishidden = true;
        if (key != "Backspace") {
            backspace = false;
            this.searchbar += key;
            this.getProductOnSearch(this.searchbar);
        }
        else {
            backspace = true;
            this.editedText = this.searchbar.slice(0, -1);
            this.searchbar = this.editedText;
            this.getProductOnSearch(this.searchbar);
        }
        console.log(this.searchbar);
        if (this.searchbar == "") {
            this.ishidden = false;
            this.arrayProduct = [];
        }
    }
    getProductOnSearch(product) {
        this.arrayProduct = [];
        let thisProduct = "";
        console.log(_assets_detailProduct_json__WEBPACK_IMPORTED_MODULE_6__.product.length);
        for (let i = 0; i < _assets_detailProduct_json__WEBPACK_IMPORTED_MODULE_6__.product.length; i++) {
            this.prods = _assets_detailProduct_json__WEBPACK_IMPORTED_MODULE_6__.product[i].title.includes(product);
            if (this.prods == true) {
                thisProduct = _assets_detailProduct_json__WEBPACK_IMPORTED_MODULE_6__.product[i].title + "-" + _assets_detailProduct_json__WEBPACK_IMPORTED_MODULE_6__.product[i].name;
                this.arrayProduct.push(thisProduct);
            }
        }
        console.log(this.arrayProduct);
    }
};
SearchPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
SearchPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-search',
        template: _raw_loader_search_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_login_login_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"], _search_page_scss__WEBPACK_IMPORTED_MODULE_3__["default"]]
    })
], SearchPage);



/***/ }),

/***/ "P8Ee":
/*!*******************************************************!*\
  !*** ./src/app/pages/search/search-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: SearchPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchPageRoutingModule", function() { return SearchPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _search_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./search.page */ "Dwri");




const routes = [
    {
        path: '',
        component: _search_page__WEBPACK_IMPORTED_MODULE_3__["SearchPage"]
    }
];
let SearchPageRoutingModule = class SearchPageRoutingModule {
};
SearchPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SearchPageRoutingModule);



/***/ }),

/***/ "bHDT":
/*!***********************************************!*\
  !*** ./src/app/pages/search/search.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".item {\n  color: whitesmoke !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxzZWFyY2gucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksNEJBQUE7QUFBSiIsImZpbGUiOiJzZWFyY2gucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi5pdGVte1xyXG4gICAgY29sb3I6IHdoaXRlc21va2UgIWltcG9ydGFudDtcclxufSJdfQ== */");

/***/ }),

/***/ "eQ5q":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/search/search.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-toolbar>\r\n    <ion-searchbar animated placeholder=\"Rechercher\" class=\"search_bar\" (keyup)=\"show_search($event.key)\"></ion-searchbar>\r\n  </ion-toolbar>\r\n\r\n  <ion-card [hidden]=ishidden>\r\n    <ion-item class=\"type_app\" routerLink=\"/type-search\" [state]=\"{ example: 'Hybride' }\">\r\n      <ion-label class=\"item\">Hybride <img class=\"search_image\" src=\"../../../assets/icon/photo.png\" /> </ion-label>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-card [hidden]=ishidden>\r\n    <ion-item class=\"type_app\" routerLink=\"/type-search\" [state]=\"{ example: 'Reflexe' }\">\r\n      <ion-label class=\"item\">Reflexe <img class=\"search_image\" src=\"../../../assets/icon/reflex.png\" /> </ion-label>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-card [hidden]=ishidden>\r\n    <ion-item class=\"type_app\" routerLink=\"/type-search\" [state]=\"{ example: 'Compact & Bridge' }\">\r\n      <ion-label class=\"item\" style=\"font-size: 90%;\">Compact & Bridge<img class=\"search_image\" src=\"../../../assets/icon/compact_bridge.png\" /></ion-label>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-card [hidden]=ishidden>\r\n    <ion-item class=\"type_app\" routerLink=\"/type-search\" [state]=\"{ example: 'Instantané' }\">\r\n      <ion-label class=\"item\" >Instantané <img class=\"search_image\" src=\"../../../assets/icon/instant.png\" /></ion-label>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-card [hidden]=ishidden>\r\n    <ion-item class=\"type_app\" routerLink=\"/type-search\" [state]=\"{ example: 'CamSport' }\">\r\n      <ion-label class=\"item\" style=\"font-size: 90%;\">CamSport <img class=\"search_image\" src=\"../../../assets/icon/cam.png\" /></ion-label>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-card [hidden]=ishidden>\r\n    <ion-item class=\"type_app\" routerLink=\"/type-search\" [state]=\"{ example: 'Objectifs' }\">\r\n      <ion-label class=\"item\">Objectifs <img class=\"search_image\" src=\"../../../assets/icon/objectif.png\" /></ion-label>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-card [hidden]=ishidden>\r\n    <ion-item class=\"type_app\" routerLink=\"/type-search\" [state]=\"{ example: 'Accessoire' }\">\r\n      <ion-label class=\"item\">Accessoire <img class=\"search_image\" src=\"../../../assets/icon/accessoire.png\" /></ion-label>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-list *ngFor=\"let product of arrayProduct\">\r\n    <ion-item routerLink=\"/type-search\" [state]=\"{ example: product }\">\r\n      <ion-label style=\"color: black;\">{{ product }}</ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n</ion-content>\r\n");

/***/ }),

/***/ "vuQK":
/*!***********************************************!*\
  !*** ./src/app/pages/search/search.module.ts ***!
  \***********************************************/
/*! exports provided: SearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchPageModule", function() { return SearchPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _search_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./search-routing.module */ "P8Ee");
/* harmony import */ var _search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./search.page */ "Dwri");







let SearchPageModule = class SearchPageModule {
};
SearchPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _search_routing_module__WEBPACK_IMPORTED_MODULE_5__["SearchPageRoutingModule"]
        ],
        declarations: [_search_page__WEBPACK_IMPORTED_MODULE_6__["SearchPage"]]
    })
], SearchPageModule);



/***/ })

}]);
//# sourceMappingURL=search-search-module.js.map