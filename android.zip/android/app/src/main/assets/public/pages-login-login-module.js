(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-login-login-module"],{

/***/ "1WlZ":
/*!*********************************************************************!*\
  !*** ./src/app/modals/forgot-password/forgot-password.component.ts ***!
  \*********************************************************************/
/*! exports provided: ForgotPasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgotPasswordComponent", function() { return ForgotPasswordComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_forgot_password_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./forgot-password.component.html */ "yK82");
/* harmony import */ var _pages_login_login_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../pages/login/login.page.scss */ "H+1c");
/* harmony import */ var _forgot_password_component_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./forgot-password.component.scss */ "LLfC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");






let ForgotPasswordComponent = class ForgotPasswordComponent {
    constructor(modal) {
        this.modal = modal;
    }
    ngOnInit() {
        console.log(this.emailer);
    }
    close() {
        this.modal.dismiss({
            'dismissed': true
        });
    }
};
ForgotPasswordComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] }
];
ForgotPasswordComponent.propDecorators = {
    emailer: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }]
};
ForgotPasswordComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-forgot-password',
        template: _raw_loader_forgot_password_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_pages_login_login_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"], _forgot_password_component_scss__WEBPACK_IMPORTED_MODULE_3__["default"]]
    })
], ForgotPasswordComponent);



/***/ }),

/***/ "F4UR":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.module.ts ***!
  \*********************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login-routing.module */ "aTZN");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "bP1B");







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"]
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })
], LoginPageModule);



/***/ }),

/***/ "LLfC":
/*!***********************************************************************!*\
  !*** ./src/app/modals/forgot-password/forgot-password.component.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-icon {\n  font-size: xx-large;\n}\n\n.logo ion-col {\n  text-align: center;\n}\n\n.logo ion-col ion-icon {\n  padding: 10%;\n  font-size: 4rem;\n  border-radius: 50%;\n  background: linear-gradient(to bottom, #f7f7f7, #e4e2ea, #d1ccdd, #c0b7cf, #b0a2c1);\n}\n\n.logo ion-col .inner-scroll {\n  color: linear-gradient(to bottom, #f7f7f7, #e4e2ea, #d1ccdd, #c0b7cf, #b0a2c1) !important;\n}\n\n.form .text {\n  padding: 0% 0%;\n}\n\n.form .text h4 {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxmb3Jnb3QtcGFzc3dvcmQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSxtQkFBQTtBQUFSOztBQUtJO0VBQ0ksa0JBQUE7QUFGUjs7QUFHUTtFQUNJLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxtRkFBQTtBQURaOztBQUdRO0VBQ0kseUZBQUE7QUFEWjs7QUFPSTtFQUNJLGNBQUE7QUFKUjs7QUFLUTtFQUNJLGtCQUFBO0FBSFoiLCJmaWxlIjoiZm9yZ290LXBhc3N3b3JkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgICAgZm9udC1zaXplOiB4eC1sYXJnZTtcclxuICAgIH1cclxufVxyXG5cclxuLmxvZ28ge1xyXG4gICAgaW9uLWNvbCB7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgICAgcGFkZGluZzogMTAlO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDRyZW07XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgI2Y3ZjdmNywgI2U0ZTJlYSwgI2QxY2NkZCwgI2MwYjdjZiwgI2IwYTJjMSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5pbm5lci1zY3JvbGwge1xyXG4gICAgICAgICAgICBjb2xvcjogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgI2Y3ZjdmNywgI2U0ZTJlYSwgI2QxY2NkZCwgI2MwYjdjZiwgI2IwYTJjMSkhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmZvcm0ge1xyXG4gICAgLnRleHQge1xyXG4gICAgICAgIHBhZGRpbmc6IDAlIDAlO1xyXG4gICAgICAgIGg0IHtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ== */");

/***/ }),

/***/ "TuYN":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/login/login.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\r\n\r\n    <ion-row class=\"logo\">\r\n        <ion-col size=\"12\" class=\"ion-align-self-center\">\r\n            <img src=\"assets/icon/logo2-transparant.png\" alt=\"\">\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row class=\"form\">\r\n        <ion-col size=\"12\">\r\n            <ion-item [ngClass]=\"isErrorMail ? 'errorEmail' : 'goodEmail'\">\r\n                <ion-label position=\"floating\">Email</ion-label>\r\n                <ion-input (keydown)=\"checkEmail()\" type=\"email\" [(ngModel)]=\"email\"></ion-input>\r\n            </ion-item>\r\n            <ion-item [ngClass]=\"password.trim().length < 5 ? 'errorEmail' : 'goodEmail'\">\r\n                <ion-label position=\"floating\">Mot de passe</ion-label>\r\n                <ion-input type=\"password\" [(ngModel)]=\"password\"></ion-input>\r\n            </ion-item>\r\n        </ion-col>\r\n        <ion-col size=\"12\">\r\n            <p class=\"forgot\" (click)=\"forgotPassword()\">mot de passe oublié?</p>\r\n        </ion-col>\r\n        <ion-col size=\"12\">\r\n            <ion-button [disabled]=\"isErrorMail || password.trim().length < 5\" expand=\"full\" class=\"btnLogin\" (click)=\"loginForm()\">Login</ion-button>\r\n        </ion-col>\r\n\r\n    </ion-row>\r\n    <p> <a routerLink=\"/register\">Vous n'avez pas encore un compte ? s'enregistrer</a> </p>\r\n</ion-content>");

/***/ }),

/***/ "aTZN":
/*!*****************************************************!*\
  !*** ./src/app/pages/login/login-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: LoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function() { return LoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "bP1B");




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ "bP1B":
/*!*******************************************!*\
  !*** ./src/app/pages/login/login.page.ts ***!
  \*******************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./login.page.html */ "TuYN");
/* harmony import */ var _login_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.page.scss */ "H+1c");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/native-storage/ngx */ "M2ZX");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/auth.service */ "lGQG");
/* harmony import */ var _modals_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../modals/forgot-password/forgot-password.component */ "1WlZ");











let LoginPage = class LoginPage {
    constructor(router, auth, platform, storage, modal, loading) {
        this.router = router;
        this.auth = auth;
        this.platform = platform;
        this.storage = storage;
        this.modal = modal;
        this.loading = loading;
        this.email = '';
        this.password = '';
        this.isErrorMail = true;
    }
    ngOnInit() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let theToken;
            if (this.platform.is("desktop")) {
                theToken = localStorage.getItem('theToken');
            }
            else {
                theToken = yield this.storage.getItem('theToken');
            }
            console.log(theToken);
            if (theToken !== undefined && theToken !== null)
                this.router.navigate(['/tabs']);
        });
    }
    forgotPassword() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modal.create({
                component: _modals_forgot_password_forgot_password_component__WEBPACK_IMPORTED_MODULE_8__["ForgotPasswordComponent"],
                componentProps: {
                    'emailer': this.email
                }
            });
            return yield modal.present();
        });
    }
    checkEmail() {
        const regex = new RegExp(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/g);
        // this.isErrorMail = !regex.test(this.email);
        this.isErrorMail = (regex.test(this.email.trim())) ? false : true;
    }
    loginForm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const load = yield this.loading.create({
                message: 'Please wait...',
            });
            yield load.present();
            this.auth.login(this.email, this.password).then((user) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                console.log(this.platform.platforms());
                if (this.platform.is("desktop")) {
                    localStorage.setItem('theToken', user.theToken);
                    localStorage.setItem('user', JSON.stringify(user.user));
                }
                else {
                    yield this.storage.setItem('theToken', user.theToken);
                    yield this.storage.setItem('user', JSON.stringify(user.user));
                }
                yield this.loading.dismiss();
                this.router.navigate(['/tabs']);
            })).catch(() => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.email = '';
                this.password = '';
                this.isErrorMail = true;
                yield this.loading.dismiss();
            }));
        });
    }
};
LoginPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"] },
    { type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_6__["NativeStorage"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] }
];
LoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-login',
        template: _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_login_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], LoginPage);



/***/ }),

/***/ "yK82":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modals/forgot-password/forgot-password.component.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n    <ion-toolbar>\r\n        <ion-buttons slot=\"start\" (click)=\"close()\">\r\n            <ion-icon name=\"chevron-back-outline\"></ion-icon>\r\n        </ion-buttons>\r\n    </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n    <ion-row class=\"logo\">\r\n        <ion-col size=\"12\" class=\"ion-align-self-center\">\r\n            <ion-icon name=\"lock-closed-outline\"></ion-icon>\r\n        </ion-col>\r\n    </ion-row>\r\n    <ion-row class=\"form\">\r\n        <ion-col class=\"text\" size=\"12\">\r\n            <h4>Vous avez oublié votre mot de pass ?</h4>\r\n            <p>Veuillez entre l'adresse de votre e-mail</p>\r\n        </ion-col>\r\n        <ion-col size=\"12\">\r\n            <ion-item>\r\n                <ion-label position=\"floating\">Email</ion-label>\r\n                <ion-input type=\"email\" [(ngModel)]=\"emailer\"></ion-input>\r\n            </ion-item>\r\n        </ion-col>\r\n        <ion-col size=\"12\">\r\n            <ion-button expand=\"full\" class=\"btnLogin\" (click)=\"loginForm()\">Envoyer</ion-button>\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=pages-login-login-module.js.map