(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"],{

/***/ "74mu":
/*!*************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/theme-ff3fc52f.js ***!
  \*************************************************************/
/*! exports provided: c, g, h, o */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return createColorClasses; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return getClassMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return hostContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "o", function() { return openURL; });
const hostContext = (selector, el) => {
  return el.closest(selector) !== null;
};
/**
 * Create the mode and color classes for the component based on the classes passed in
 */
const createColorClasses = (color, cssClassMap) => {
  return (typeof color === 'string' && color.length > 0) ? Object.assign({ 'ion-color': true, [`ion-color-${color}`]: true }, cssClassMap) : cssClassMap;
};
const getClassList = (classes) => {
  if (classes !== undefined) {
    const array = Array.isArray(classes) ? classes : classes.split(' ');
    return array
      .filter(c => c != null)
      .map(c => c.trim())
      .filter(c => c !== '');
  }
  return [];
};
const getClassMap = (classes) => {
  const map = {};
  getClassList(classes).forEach(c => map[c] = true);
  return map;
};
const SCHEME = /^[a-z][a-z0-9+\-.]*:/;
const openURL = async (url, ev, direction, animation) => {
  if (url != null && url[0] !== '#' && !SCHEME.test(url)) {
    const router = document.querySelector('ion-router');
    if (router) {
      if (ev != null) {
        ev.preventDefault();
      }
      return router.push(url, direction, animation);
    }
  }
  return false;
};




/***/ }),

/***/ "H+1c":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".logo {\n  height: 40%;\n}\n.logo .img {\n  margin-top: 4%;\n}\n.logo .marque {\n  font-size: xx-large;\n  margin: 0;\n  color: #B0A2C1;\n  text-align: center;\n}\n.type_app {\n  --background: linear-gradient(to right top, #b0a2c1, #c0b7cf, #d1ccdd, #e4e2ea, #f7f7f7);\n}\n.form .btnLogin {\n  --background: linear-gradient(to right top, #b0a2c1, #c0b7cf, #d1ccdd, #e4e2ea, #f7f7f7);\n  --backgroun-hover: linear-gradient(to right top, #b0a2c1, #c0b7cf, #d1ccdd, #e4e2ea, #f7f7f7);\n  --background-focused: linear-gradient(to right top, #b0a2c1, #c0b7cf, #d1ccdd, #e4e2ea, #f7f7f7);\n  --backgroun-activated: linear-gradient(to right top, #b0a2c1, #c0b7cf, #d1ccdd, #e4e2ea, #f7f7f7);\n}\n.form .errorEmail {\n  border-bottom: #ff0062;\n  --border-color: #ff0062;\n  --highlight-background: #ff0062;\n}\n.form .goodEmail {\n  border-bottom: #12eb48;\n  --border-color: #12eb48;\n  --highlight-background: #12eb48;\n}\n.form .forgot {\n  margin-top: 0;\n  text-align: end;\n}\np,\na {\n  color: #c9c9c9;\n  text-align: center;\n}\n.search_image {\n  width: 24%;\n  float: right;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxsb2dpbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0FBQ0o7QUFBSTtFQUNJLGNBQUE7QUFFUjtBQUFJO0VBQ0ksbUJBQUE7RUFDQSxTQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBRVI7QUFFQTtFQUNJLHdGQUFBO0FBQ0o7QUFHSTtFQUNJLHdGQUFBO0VBQ0EsNkZBQUE7RUFDQSxnR0FBQTtFQUNBLGlHQUFBO0FBQVI7QUFFSTtFQUNJLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSwrQkFBQTtBQUFSO0FBRUk7RUFDSSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsK0JBQUE7QUFBUjtBQUVJO0VBQ0ksYUFBQTtFQUNBLGVBQUE7QUFBUjtBQUlBOztFQUVJLGNBQUE7RUFDQSxrQkFBQTtBQURKO0FBS0E7RUFDSSxVQUFBO0VBQ0EsWUFBQTtBQUZKIiwiZmlsZSI6ImxvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sb2dvIHtcclxuICAgIGhlaWdodDogNDAlO1xyXG4gICAgLmltZyB7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogNCU7XHJcbiAgICB9XHJcbiAgICAubWFycXVlIHtcclxuICAgICAgICBmb250LXNpemU6IHh4LWxhcmdlO1xyXG4gICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICBjb2xvcjogI0IwQTJDMTtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB9XHJcbn1cclxuXHJcbi50eXBlX2FwcHtcclxuICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0IHRvcCwgI2IwYTJjMSwgI2MwYjdjZiwgI2QxY2NkZCwgI2U0ZTJlYSwgI2Y3ZjdmNyk7XHJcbn1cclxuXHJcbi5mb3Jte1xyXG4gICAgLmJ0bkxvZ2lue1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIHJpZ2h0IHRvcCwgI2IwYTJjMSwgI2MwYjdjZiwgI2QxY2NkZCwgI2U0ZTJlYSwgI2Y3ZjdmNyk7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW4taG92ZXI6IGxpbmVhci1ncmFkaWVudCh0byByaWdodCB0b3AsICNiMGEyYzEsICNjMGI3Y2YsICNkMWNjZGQsICNlNGUyZWEsICNmN2Y3ZjcpO1xyXG4gICAgICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQgdG9wLCAjYjBhMmMxLCAjYzBiN2NmLCAjZDFjY2RkLCAjZTRlMmVhLCAjZjdmN2Y3KTsgXHJcbiAgICAgICAgLS1iYWNrZ3JvdW4tYWN0aXZhdGVkOiBsaW5lYXItZ3JhZGllbnQodG8gcmlnaHQgdG9wLCAjYjBhMmMxLCAjYzBiN2NmLCAjZDFjY2RkLCAjZTRlMmVhLCAjZjdmN2Y3KTtcclxuICAgIH1cclxuICAgIC5lcnJvckVtYWlsIHtcclxuICAgICAgICBib3JkZXItYm90dG9tOiAjZmYwMDYyO1xyXG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiAjZmYwMDYyO1xyXG4gICAgICAgIC0taGlnaGxpZ2h0LWJhY2tncm91bmQ6ICNmZjAwNjI7XHJcbiAgICB9XHJcbiAgICAuZ29vZEVtYWlsIHtcclxuICAgICAgICBib3JkZXItYm90dG9tOiAjMTJlYjQ4O1xyXG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiAjMTJlYjQ4O1xyXG4gICAgICAgIC0taGlnaGxpZ2h0LWJhY2tncm91bmQ6ICMxMmViNDg7XHJcbiAgICB9XHJcbiAgICAuZm9yZ290IHtcclxuICAgICAgICBtYXJnaW4tdG9wOiAwO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGVuZDtcclxuICAgIH1cclxufVxyXG5cclxucCxcclxuYSB7XHJcbiAgICBjb2xvcjogI2M5YzljOTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuXHJcbi5zZWFyY2hfaW1hZ2V7XHJcbiAgICB3aWR0aDogMjQlO1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG59XHJcblxyXG4iXX0= */");

/***/ }),

/***/ "JbSX":
/*!*********************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/button-active-4927a4c1.js ***!
  \*********************************************************************/
/*! exports provided: c */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return createButtonActiveGesture; });
/* harmony import */ var _index_7a8b7a1c_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-7a8b7a1c.js */ "wEJo");
/* harmony import */ var _haptic_27b3f981_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./haptic-27b3f981.js */ "qULd");
/* harmony import */ var _index_f49d994d_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index-f49d994d.js */ "iWo5");




const createButtonActiveGesture = (el, isButton) => {
  let currentTouchedButton;
  let initialTouchedButton;
  const activateButtonAtPoint = (x, y, hapticFeedbackFn) => {
    if (typeof document === 'undefined') {
      return;
    }
    const target = document.elementFromPoint(x, y);
    if (!target || !isButton(target)) {
      clearActiveButton();
      return;
    }
    if (target !== currentTouchedButton) {
      clearActiveButton();
      setActiveButton(target, hapticFeedbackFn);
    }
  };
  const setActiveButton = (button, hapticFeedbackFn) => {
    currentTouchedButton = button;
    if (!initialTouchedButton) {
      initialTouchedButton = currentTouchedButton;
    }
    const buttonToModify = currentTouchedButton;
    Object(_index_7a8b7a1c_js__WEBPACK_IMPORTED_MODULE_0__["c"])(() => buttonToModify.classList.add('ion-activated'));
    hapticFeedbackFn();
  };
  const clearActiveButton = (dispatchClick = false) => {
    if (!currentTouchedButton) {
      return;
    }
    const buttonToModify = currentTouchedButton;
    Object(_index_7a8b7a1c_js__WEBPACK_IMPORTED_MODULE_0__["c"])(() => buttonToModify.classList.remove('ion-activated'));
    /**
     * Clicking on one button, but releasing on another button
     * does not dispatch a click event in browsers, so we
     * need to do it manually here. Some browsers will
     * dispatch a click if clicking on one button, dragging over
     * another button, and releasing on the original button. In that
     * case, we need to make sure we do not cause a double click there.
     */
    if (dispatchClick && initialTouchedButton !== currentTouchedButton) {
      currentTouchedButton.click();
    }
    currentTouchedButton = undefined;
  };
  return Object(_index_f49d994d_js__WEBPACK_IMPORTED_MODULE_2__["createGesture"])({
    el,
    gestureName: 'buttonActiveDrag',
    threshold: 0,
    onStart: ev => activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_27b3f981_js__WEBPACK_IMPORTED_MODULE_1__["a"]),
    onMove: ev => activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_27b3f981_js__WEBPACK_IMPORTED_MODULE_1__["b"]),
    onEnd: () => {
      clearActiveButton(true);
      Object(_haptic_27b3f981_js__WEBPACK_IMPORTED_MODULE_1__["h"])();
      initialTouchedButton = undefined;
    }
  });
};




/***/ }),

/***/ "UDca":
/*!***************************************!*\
  !*** ./src/assets/detailProduct.json ***!
  \***************************************/
/*! exports provided: product, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"product\":[{\"name\":\"5555-k\",\"title\":\"sony\",\"categorie\":\"Hybride\",\"image\":\"hybride1\",\"type\":\"\",\"description\":\"UNE OPÉRABILITÉ PROFESSIONNELLE AVANCÉE : \\n Nouveau menu issu de l'Alpha 7SIII, batterie Z haute capacité, HDMI 2.1, Ethernet et Wi-Fi ultrarapide, double slot mémoire bi-format SD-UHSII et CF Express Type A; un outil parfait pour les professionnels de l'image qui veulent tirer le meilleur parti de leur appareil photo.\",\"prix\":\"480\"},{\"name\":\"4879-t\",\"title\":\"canon\",\"categorie\":\"Reflexe\",\"image\":\"canon_reflex\"},{\"name\":\"2240X\",\"title\":\"gopro\",\"categorie\":\"CamSport\",\"image\":\"goPro\",\"type\":\"\",\"description\":\"UNE OPÉRABILITÉ PROFESSIONNELLE AVANCÉE : \\n Nouveau menu issu de l'Alpha 7SIII, batterie Z haute capacité, HDMI 2.1, Ethernet et Wi-Fi ultrarapide, double slot mémoire bi-format SD-UHSII et CF Express Type A; un outil parfait pour les professionnels de l'image qui veulent tirer le meilleur parti de leur appareil photo.\"},{\"name\":\"97856\",\"title\":\"canon\",\"categorie\":\"Compact & Bridge\",\"image\":\"compactBridge\",\"type\":\"\",\"description\":\"UNE OPÉRABILITÉ PROFESSIONNELLE AVANCÉE : \\n Nouveau menu issu de l'Alpha 7SIII, batterie Z haute capacité, HDMI 2.1, Ethernet et Wi-Fi ultrarapide, double slot mémoire bi-format SD-UHSII et CF Express Type A; un outil parfait pour les professionnels de l'image qui veulent tirer le meilleur parti de leur appareil photo.\"},{\"name\":\"2242X\",\"title\":\"gopro\",\"categorie\":\"CamSport\",\"image\":\"goPro\",\"type\":\"\",\"description\":\"UNE OPÉRABILITÉ PROFESSIONNELLE AVANCÉE : \\n Nouveau menu issu de l'Alpha 7SIII, batterie Z haute capacité, HDMI 2.1, Ethernet et Wi-Fi ultrarapide, double slot mémoire bi-format SD-UHSII et CF Express Type A; un outil parfait pour les professionnels de l'image qui veulent tirer le meilleur parti de leur appareil photo.\"},{\"name\":\"2248Y\",\"title\":\"polaroïd\",\"categorie\":\"Instantané\",\"image\":\"polaroid\",\"type\":\"\",\"description\":\"UNE OPÉRABILITÉ PROFESSIONNELLE AVANCÉE : \\n Nouveau menu issu de l'Alpha 7SIII, batterie Z haute capacité, HDMI 2.1, Ethernet et Wi-Fi ultrarapide, double slot mémoire bi-format SD-UHSII et CF Express Type A; un outil parfait pour les professionnels de l'image qui veulent tirer le meilleur parti de leur appareil photo.\"},{\"name\":\"12345P\",\"title\":\"canon\",\"categorie\":\"Objectifs\",\"image\":\"objectif\",\"type\":\"\",\"description\":\"UNE OPÉRABILITÉ PROFESSIONNELLE AVANCÉE : \\n Nouveau menu issu de l'Alpha 7SIII, batterie Z haute capacité, HDMI 2.1, Ethernet et Wi-Fi ultrarapide, double slot mémoire bi-format SD-UHSII et CF Express Type A; un outil parfait pour les professionnels de l'image qui veulent tirer le meilleur parti de leur appareil photo.\"},{\"name\":\"98745-Z\",\"title\":\"fugifilm\",\"categorie\":\"Accessoire\",\"image\":\"accessoire\",\"type\":\"\",\"description\":\"UNE OPÉRABILITÉ PROFESSIONNELLE AVANCÉE : \\n Nouveau menu issu de l'Alpha 7SIII, batterie Z haute capacité, HDMI 2.1, Ethernet et Wi-Fi ultrarapide, double slot mémoire bi-format SD-UHSII et CF Express Type A; un outil parfait pour les professionnels de l'image qui veulent tirer le meilleur parti de leur appareil photo.\"},{\"name\":\"98745-Z\",\"title\":\"canon\",\"categorie\":\"Accessoire\",\"image\":\"accessoire-canon\",\"type\":\"\",\"description\":\"UNE OPÉRABILITÉ PROFESSIONNELLE AVANCÉE : \\n Nouveau menu issu de l'Alpha 7SIII, batterie Z haute capacité, HDMI 2.1, Ethernet et Wi-Fi ultrarapide, double slot mémoire bi-format SD-UHSII et CF Express Type A; un outil parfait pour les professionnels de l'image qui veulent tirer le meilleur parti de leur appareil photo.\"}]}");

/***/ }),

/***/ "acej":
/*!**************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/framework-delegate-4392cd63.js ***!
  \**************************************************************************/
/*! exports provided: a, d */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return attachComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return detachComponent; });
/* harmony import */ var _helpers_dd7e4b7b_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./helpers-dd7e4b7b.js */ "1vRN");


const attachComponent = async (delegate, container, component, cssClasses, componentProps) => {
  if (delegate) {
    return delegate.attachViewToDom(container, component, componentProps, cssClasses);
  }
  if (typeof component !== 'string' && !(component instanceof HTMLElement)) {
    throw new Error('framework delegate is missing');
  }
  const el = (typeof component === 'string')
    ? container.ownerDocument && container.ownerDocument.createElement(component)
    : component;
  if (cssClasses) {
    cssClasses.forEach(c => el.classList.add(c));
  }
  if (componentProps) {
    Object.assign(el, componentProps);
  }
  container.appendChild(el);
  await new Promise(resolve => Object(_helpers_dd7e4b7b_js__WEBPACK_IMPORTED_MODULE_0__["c"])(el, resolve));
  return el;
};
const detachComponent = (delegate, element) => {
  if (element) {
    if (delegate) {
      const container = element.parentElement;
      return delegate.removeViewFromDom(container, element);
    }
    element.remove();
  }
  return Promise.resolve();
};




/***/ }),

/***/ "h3R7":
/*!***********************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/spinner-configs-cd7845af.js ***!
  \***********************************************************************/
/*! exports provided: S */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "S", function() { return SPINNERS; });
const spinners = {
  'bubbles': {
    dur: 1000,
    circles: 9,
    fn: (dur, index, total) => {
      const animationDelay = `${(dur * index / total) - dur}ms`;
      const angle = 2 * Math.PI * index / total;
      return {
        r: 5,
        style: {
          'top': `${9 * Math.sin(angle)}px`,
          'left': `${9 * Math.cos(angle)}px`,
          'animation-delay': animationDelay,
        }
      };
    }
  },
  'circles': {
    dur: 1000,
    circles: 8,
    fn: (dur, index, total) => {
      const step = index / total;
      const animationDelay = `${(dur * step) - dur}ms`;
      const angle = 2 * Math.PI * step;
      return {
        r: 5,
        style: {
          'top': `${9 * Math.sin(angle)}px`,
          'left': `${9 * Math.cos(angle)}px`,
          'animation-delay': animationDelay,
        }
      };
    }
  },
  'circular': {
    dur: 1400,
    elmDuration: true,
    circles: 1,
    fn: () => {
      return {
        r: 20,
        cx: 48,
        cy: 48,
        fill: 'none',
        viewBox: '24 24 48 48',
        transform: 'translate(0,0)',
        style: {}
      };
    }
  },
  'crescent': {
    dur: 750,
    circles: 1,
    fn: () => {
      return {
        r: 26,
        style: {}
      };
    }
  },
  'dots': {
    dur: 750,
    circles: 3,
    fn: (_, index) => {
      const animationDelay = -(110 * index) + 'ms';
      return {
        r: 6,
        style: {
          'left': `${9 - (9 * index)}px`,
          'animation-delay': animationDelay,
        }
      };
    }
  },
  'lines': {
    dur: 1000,
    lines: 12,
    fn: (dur, index, total) => {
      const transform = `rotate(${30 * index + (index < 6 ? 180 : -180)}deg)`;
      const animationDelay = `${(dur * index / total) - dur}ms`;
      return {
        y1: 17,
        y2: 29,
        style: {
          'transform': transform,
          'animation-delay': animationDelay,
        }
      };
    }
  },
  'lines-small': {
    dur: 1000,
    lines: 12,
    fn: (dur, index, total) => {
      const transform = `rotate(${30 * index + (index < 6 ? 180 : -180)}deg)`;
      const animationDelay = `${(dur * index / total) - dur}ms`;
      return {
        y1: 12,
        y2: 20,
        style: {
          'transform': transform,
          'animation-delay': animationDelay,
        }
      };
    }
  }
};
const SPINNERS = spinners;




/***/ }),

/***/ "lGQG":
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");



let AuthService = class AuthService {
    constructor(http) {
        this.http = http;
        this.url = 'http://localhost:8081/auth'; // aaaaaaa@aaaaaaa.fr
    }
    login(email, password) {
        return new Promise((resolve, rejects) => {
            this.http.post(this.url + '/login', { email: email, password: password }).subscribe((data) => {
                (!data.token) ? rejects(false) : resolve(data);
            });
        });
    }
    register(user) {
        return new Promise((resolve, rejects) => {
            this.http.post(this.url + '/register', user).subscribe((data) => {
                (!data.token) ? rejects(data.message) : resolve(data);
            });
        });
    }
    getProfile() {
        return this.http.get(this.url + '/profil');
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
AuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ "qULd":
/*!**************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/haptic-27b3f981.js ***!
  \**************************************************************/
/*! exports provided: a, b, c, d, h */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return hapticSelectionStart; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return hapticSelectionChanged; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return hapticSelection; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return hapticImpact; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return hapticSelectionEnd; });
const HapticEngine = {
  getEngine() {
    const win = window;
    return (win.TapticEngine) || (win.Capacitor && win.Capacitor.isPluginAvailable('Haptics') && win.Capacitor.Plugins.Haptics);
  },
  available() {
    return !!this.getEngine();
  },
  isCordova() {
    return !!window.TapticEngine;
  },
  isCapacitor() {
    const win = window;
    return !!win.Capacitor;
  },
  impact(options) {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    const style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
    engine.impact({ style });
  },
  notification(options) {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    const style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
    engine.notification({ style });
  },
  selection() {
    this.impact({ style: 'light' });
  },
  selectionStart() {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    if (this.isCapacitor()) {
      engine.selectionStart();
    }
    else {
      engine.gestureSelectionStart();
    }
  },
  selectionChanged() {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    if (this.isCapacitor()) {
      engine.selectionChanged();
    }
    else {
      engine.gestureSelectionChanged();
    }
  },
  selectionEnd() {
    const engine = this.getEngine();
    if (!engine) {
      return;
    }
    if (this.isCapacitor()) {
      engine.selectionEnd();
    }
    else {
      engine.gestureSelectionEnd();
    }
  }
};
/**
 * Trigger a selection changed haptic event. Good for one-time events
 * (not for gestures)
 */
const hapticSelection = () => {
  HapticEngine.selection();
};
/**
 * Tell the haptic engine that a gesture for a selection change is starting.
 */
const hapticSelectionStart = () => {
  HapticEngine.selectionStart();
};
/**
 * Tell the haptic engine that a selection changed during a gesture.
 */
const hapticSelectionChanged = () => {
  HapticEngine.selectionChanged();
};
/**
 * Tell the haptic engine we are done with a gesture. This needs to be
 * called lest resources are not properly recycled.
 */
const hapticSelectionEnd = () => {
  HapticEngine.selectionEnd();
};
/**
 * Use this to indicate success/failure/warning to the user.
 * options should be of the type `{ style: 'light' }` (or `medium`/`heavy`)
 */
const hapticImpact = (options) => {
  HapticEngine.impact(options);
};




/***/ })

}]);
//# sourceMappingURL=common.js.map