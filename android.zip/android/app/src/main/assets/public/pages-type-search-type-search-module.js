(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-type-search-type-search-module"],{

/***/ "/km9":
/*!*********************************************************!*\
  !*** ./src/app/pages/type-search/type-search.module.ts ***!
  \*********************************************************/
/*! exports provided: TypeSearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TypeSearchPageModule", function() { return TypeSearchPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _type_search_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./type-search-routing.module */ "5g/W");
/* harmony import */ var _type_search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./type-search.page */ "hN7/");







let TypeSearchPageModule = class TypeSearchPageModule {
};
TypeSearchPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _type_search_routing_module__WEBPACK_IMPORTED_MODULE_5__["TypeSearchPageRoutingModule"]
        ],
        declarations: [_type_search_page__WEBPACK_IMPORTED_MODULE_6__["TypeSearchPage"]]
    })
], TypeSearchPageModule);



/***/ }),

/***/ "1ATU":
/*!*********************************************************!*\
  !*** ./src/app/pages/type-search/type-search.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0eXBlLXNlYXJjaC5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "5g/W":
/*!*****************************************************************!*\
  !*** ./src/app/pages/type-search/type-search-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: TypeSearchPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TypeSearchPageRoutingModule", function() { return TypeSearchPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _type_search_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./type-search.page */ "hN7/");




const routes = [
    {
        path: '',
        component: _type_search_page__WEBPACK_IMPORTED_MODULE_3__["TypeSearchPage"]
    }
];
let TypeSearchPageRoutingModule = class TypeSearchPageRoutingModule {
};
TypeSearchPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TypeSearchPageRoutingModule);



/***/ }),

/***/ "8fES":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/type-search/type-search.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n        <ion-back-button></ion-back-button>\r\n      </ion-buttons>\r\n      <ion-title style=\"float: right;\">{{item.example}}</ion-title>\r\n    </ion-toolbar>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-row *ngFor=\"let product of arrayProd\" >\r\n    <ion-card>\r\n      <ion-card-header>\r\n        <ion-card-subtitle>{{product.title}}-{{product.name}} </ion-card-subtitle>\r\n        <img src=\" {{img}}{{product.image}}.png\" alt=\"\" style=\"width: 60%;\">\r\n      </ion-card-header>\r\n    \r\n      <ion-card-content>\r\n          <p> prix :  {{product.prix}} €</p>\r\n          \r\n          <p> description <i class=\"ion-text-wrap\" style=\"font-size: small;\"> : {{product.description}} </i> </p>\r\n      </ion-card-content>\r\n    \r\n    </ion-card>\r\n  </ion-row>\r\n</ion-content>\r\n");

/***/ }),

/***/ "hN7/":
/*!*******************************************************!*\
  !*** ./src/app/pages/type-search/type-search.page.ts ***!
  \*******************************************************/
/*! exports provided: TypeSearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TypeSearchPage", function() { return TypeSearchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_type_search_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./type-search.page.html */ "8fES");
/* harmony import */ var _type_search_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./type-search.page.scss */ "1ATU");
/* harmony import */ var _assets_detailProduct_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../assets/detailProduct.json */ "UDca");
var _assets_detailProduct_json__WEBPACK_IMPORTED_MODULE_3___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../../../assets/detailProduct.json */ "UDca", 1);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "tk/3");







let TypeSearchPage = class TypeSearchPage {
    constructor(router, route, http) {
        this.router = router;
        this.route = route;
        this.http = http;
        this.description_hidden = true;
        this.prods = _assets_detailProduct_json__WEBPACK_IMPORTED_MODULE_3__.product;
        this.item = "";
        this.arrayProd = [];
        this.img = "../../../assets/img/";
    }
    ngOnInit() {
        this.item = this.router.getCurrentNavigation().extras.state.example;
        console.log(this.item);
        console.log(this.prods);
        this.getProduct();
        console.log(this.arrayProd);
    }
    getProduct() {
        let nameProd;
        for (let i = 0; i < this.prods.length; i++) {
            nameProd = this.prods[i].title + "-" + this.prods[i].name;
            if (this.prods[i].categorie == this.item || nameProd == this.item) {
                this.arrayProd.push(this.prods[i]);
            }
        }
    }
};
TypeSearchPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"] }
];
TypeSearchPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-type-search',
        template: _raw_loader_type_search_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_type_search_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TypeSearchPage);



/***/ })

}]);
//# sourceMappingURL=pages-type-search-type-search-module.js.map